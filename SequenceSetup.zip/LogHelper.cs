﻿namespace SequenceEngine
{
  public static class LogHelper
  {
    public static void Log(string message)
    {
      if (true)
      {
        Logger.Log.Debug(message);
      }
    }
  }
}